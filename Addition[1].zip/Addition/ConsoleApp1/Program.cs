﻿using System;
using System.Security.Cryptography;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int no1;
            int no2;
            int sum = 0;
            Console.WriteLine("Enter the first number :");
            no1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the second number :");
            no2 = int.Parse(Console.ReadLine());


            Class_2 ce = new Class_2();
            ce.setFirst(no1);
            ce.setSecond(no2);
            ce.setsum(sum);
            Console.WriteLine("Sum is :" + ce.getsum());
            int.Parse(Console.ReadLine());


        }
    }
}
