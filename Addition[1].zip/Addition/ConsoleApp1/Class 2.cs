﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class Class_2
    {
        private int first;
        private int second;
        private int sum;

        public void setFirst(int number)
        {
            first = number;
        }
       public int getFirst()
        {
            return first;
        }

        public void setSecond(int number1)
        {
            second = number1;
        }

        public int getsecond()
        {
            return second;
        }

        public void setsum(int sumnum)
        {
            sum = sumnum + first + second;
        }

        public int getsum()
        {
            return sum;
        }
    }
}
