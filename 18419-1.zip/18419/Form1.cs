﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _18419
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double number1, number2, sum;

            number1 = double.Parse(txtNumber1.Text);
            number2 = double.Parse(txtNumber2.Text);

            sum = number1 + number2;

            txtAnswer.Text = sum.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double number1, number2, sub;

            number1 = double.Parse(txtNumber1.Text);
            number2 = double.Parse(txtNumber2.Text);

            sub = number1 - number2;

            txtAnswer.Text = sub.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double number1, number2, mul;

            number1 = double.Parse(txtNumber1.Text);
            number2 = double.Parse(txtNumber2.Text);

            mul = number1 * number2;

            txtAnswer.Text = mul.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            double number1, number2, div;

            number1 = double.Parse(txtNumber1.Text);
            number2 = double.Parse(txtNumber2.Text);

            div = number1 / number2;

            txtAnswer.Text = div.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            txtNumber1.Text = null;
            txtNumber2.Text = null;
            txtAnswer.Text = null;
        }
    }
}
